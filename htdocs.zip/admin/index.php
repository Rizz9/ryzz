<?php
session_start();

// === KONFIGURASI ===
$adminUser = 'rizki';
$adminPass = 'rizki@123';
$uploadDir = realpath(__DIR__ . '/../upl');
if (!$uploadDir || !is_dir($uploadDir)) {
  die("❌ Folder upload tidak ditemukan!");
}

$maxUploadSize = $_SESSION['max_size'] ?? 500 * 1024; // 500KB
$allowed_ext = ['txt', 'html'];

if (isset($_POST['login'])) {
  if ($_POST['user'] === $adminUser && $_POST['pass'] === $adminPass) {
    $_SESSION['admin'] = true;
  } else {
    $msg = "❌ Login gagal!";
  }
}

if (isset($_GET['logout'])) {
  session_destroy();
  header("Location: ?");
  exit;
}

if (isset($_POST['newpass']) && $_SESSION['admin']) {
  $adminPass = $_POST['newpass'];
  $msg = "✅ Password diubah (sementara).";
}

if (isset($_POST['maxsize']) && $_SESSION['admin']) {
  $_SESSION['max_size'] = intval($_POST['maxsize']) * 1024;
  $msg = "✅ Max upload size diubah menjadi {$_POST['maxsize']} KB.";
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file']) && $_SESSION['admin']) {
  $filename = basename($_FILES['file']['name']);
  $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
  if ($_FILES['file']['size'] > $maxUploadSize) {
    $msg = "❌ File terlalu besar.";
  } else {
    $target = $uploadDir . '/' . $filename;
    if (move_uploaded_file($_FILES['file']['tmp_name'], $target)) {
      $msg = "✅ Upload sukses.";
    } else {
      $msg = "❌ Gagal upload.";
    }
  }
}

if (isset($_GET['delete']) && $_SESSION['admin']) {
  $target = $uploadDir . '/' . basename($_GET['delete']);
  if (is_file($target)) unlink($target);
  header("Location: ?");
  exit;
}

if (isset($_POST['renamebtn']) && $_SESSION['admin']) {
  $old = $uploadDir . '/' . basename($_POST['oldname']);
  $new = $uploadDir . '/' . basename($_POST['newname']);
  rename($old, $new);
  header("Location: ?");
  exit;
}

if (isset($_POST['saveedit']) && $_SESSION['admin']) {
  $fileToEdit = $uploadDir . '/' . basename($_POST['editname']);
  file_put_contents($fileToEdit, $_POST['filecontent']);
  $msg = "✅ File berhasil disimpan.";
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Uploader R07</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body class="bg-light">
<div class="container py-4">
  <div class="d-flex justify-content-between align-items-center mb-4">
    <h4>📁 Uploader R07</h4>
    <div class="dropdown">
      <button class="btn btn-light dropdown-toggle" data-bs-toggle="dropdown">
        <img src="https://i.pravatar.cc/30" class="rounded-circle">
      </button>
      <ul class="dropdown-menu dropdown-menu-end">
        <li><span class="dropdown-item-text">Status: <?= $_SESSION['admin'] ? 'Admin' : 'User' ?></span></li>
        <li><span class="dropdown-item-text">IP: <?= $_SERVER['REMOTE_ADDR'] ?></span></li>
        <li><span class="dropdown-item-text">UA: <?= $_SERVER['HTTP_USER_AGENT'] ?></span></li>
        <?php if ($_SESSION['admin']): ?>
          <li><form method="post" class="px-3 py-2"><input type="text" name="newpass" class="form-control" placeholder="New password"><button class="btn btn-sm btn-primary mt-2">Ubah Password</button></form></li>
          <li><form method="post" class="px-3 py-2"><input type="number" name="maxsize" class="form-control" placeholder="Max KB"><button class="btn btn-sm btn-secondary mt-2">Set Max Upload</button></form></li>
          <li><hr class="dropdown-divider"></li>
          <li><a class="dropdown-item text-danger" href="?logout=1">Logout</a></li>
        <?php endif; ?>
      </ul>
    </div>
  </div>

  <?php if (isset($msg)) echo "<div class='alert alert-info'>$msg</div>"; ?>

  <?php if (!isset($_SESSION['admin'])): ?>
    <form method="post" class="row g-2">
      <div class="col"><input type="text" name="user" class="form-control" placeholder="Username"></div>
      <div class="col"><input type="password" name="pass" class="form-control" placeholder="Password"></div>
      <div class="col"><button name="login" class="btn btn-primary">Login</button></div>
    </form>
  <?php else: ?>

    <form method="post" enctype="multipart/form-data" class="mb-3">
      <div class="input-group">
        <input type="file" name="file" class="form-control">
        <button class="btn btn-success">Upload</button>
      </div>
    </form>

    <h5>Daftar File</h5>
    <table class="table table-striped">
      <thead><tr><th>Nama</th><th>Ukuran</th><th>Aksi</th></tr></thead>
      <tbody>
      <?php
      foreach (scandir($uploadDir) as $file) {
        if (is_dir($uploadDir . '/' . $file)) continue;
        $size = filesize($uploadDir . '/' . $file);
        echo "<tr><td>$file</td><td>{$size} B</td><td>";
        echo "<a href='../upl/" . rawurlencode($file) . "' target='_blank' class='btn btn-sm btn-info'>View</a> ";
        echo "<a href='../upl/" . rawurlencode($file) . "' download class='btn btn-sm btn-primary'>Download</a> ";
        echo "<a href='?delete=" . urlencode($file) . "' class='btn btn-sm btn-danger' onclick=\"return confirm('Hapus?')\">Delete</a> ";
        echo "<form method='post' class='d-inline'><input type='hidden' name='oldname' value='$file'>";
        echo "<input type='text' name='newname' placeholder='Rename' class='form-control d-inline' style='width:120px;'>";
        echo "<button name='renamebtn' class='btn btn-sm btn-warning'>Rename</button></form> ";
        echo "<form method='post' class='d-inline'><input type='hidden' name='editname' value='$file'>";
        echo "<textarea name='filecontent' class='form-control' rows='3'>" . htmlspecialchars(file_get_contents($uploadDir . '/' . $file)) . "</textarea>";
        echo "<button name='saveedit' class='btn btn-sm btn-success mt-1'>Save Edit</button></form>";
        echo "</td></tr>";
      }
      ?>
      </tbody>
    </table>

  <?php endif; ?>
</div>
</body>
</html>