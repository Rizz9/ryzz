<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Tools Online | Mr.R07</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
  <style>
    body {
      background-color: #f8f9fa;
    }
    .avatar {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      background: url('foto.jpeg') center/cover no-repeat;
    }
    .dropdown-menu-custom {
      max-height: 400px;
      overflow-y: auto;
    }
  </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm px-3">
  <div class="container-fluid">
    <div class="d-flex align-items-center gap-3">
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown">
        <span class="navbar-toggler-icon"></span>
      </button>
      <span class="fw-bold fs-5">home</span>
    </div>
    <div class="collapse navbar-collapse justify-content-center" id="navbarNavDropdown">
      <ul class="navbar-nav">
        <li class="nav-item"><a class="nav-link" href="upl">📤 Uploader</a></li>
        <li class="nav-item"><a class="nav-link" href="admin">🔐 Login Admin</a></li>

        <!-- Dropdown Tools -->
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
            🧰 All Tools
          </a>
          <ul class="dropdown-menu dropdown-menu-custom">

            <!-- 🛠️ Pentesting -->
            <li><h6 class="dropdown-header">🔎 Pentesting Tools</h6></li>
            <li><a class="dropdown-item" href="tools/pentesting/whois_lookup.php">Whois Lookup</a></li>
            <li><a class="dropdown-item" href="tools/pentesting/subdomain_finder.php">Subdomain Finder</a></li>
            <li><a class="dropdown-item" href="tools/pentesting/port_scanner.php">Port Scanner</a></li>
            <li><a class="dropdown-item" href="tools/pentesting/da_pa_checker.php">DA/PA Checker</a></li>
            <li><a class="dropdown-item" href="tools/pentesting/pagespeed_checker.php">PageSpeed Checker</a></li>
            <li><a class="dropdown-item" href="tools/pentesting/ssl_checker.php">SSL Checker</a></li>
            <li><a class="dropdown-item" href="tools/pentesting/website_screenshot.php">Website Screenshot</a></li>
            <li><a class="dropdown-item" href="tools/pentesting/http_header_checker.php">HTTP Header Checker</a></li>

            <li><hr class="dropdown-divider"></li>

            <!-- 📺 Media -->
            <li><h6 class="dropdown-header">📽️ Media Tools</h6></li>
            <li><a class="dropdown-item" href="tools/media/youtube_downloader.php">YouTube Downloader</a></li>
            <li><a class="dropdown-item" href="tools/media/tiktok_downloader.php">TikTok Downloader</a></li>
            <li><a class="dropdown-item" href="tools/media/instagram_downloader.php">Instagram Downloader</a></li>
            <li><a class="dropdown-item" href="tools/media/mp3_to_mp4.php">MP3 to MP4</a></li>
            <li><a class="dropdown-item" href="tools/media/mp4_to_mp3.php">MP4 to MP3</a></li>
            <li><a class="dropdown-item" href="tools/media/image_downloader.php">Image Downloader</a></li>

            <li><hr class="dropdown-divider"></li>

            <!-- ⚙️ Generator -->
            <li><h6 class="dropdown-header">🧪 Generator Tools</h6></li>
            <li><a class="dropdown-item" href="tools/generator/hash_generator.php">Hash Generator</a></li>
            <li><a class="dropdown-item" href="tools/generator/encode_decode.php">Encode/Decode</a></li>
            <li><a class="dropdown-item" href="tools/generator/script_deface_generator.php">Script Deface Generator</a></li>
          </ul>
        </li>
      </ul>
    </div>
    <div class="d-flex align-items-center gap-3">
      <button class="btn btn-outline-secondary" type="button" data-bs-toggle="popover" title="Info" data-bs-content="MASIH TAHAP PEMBUATAN BRO SABAR YA HEHEHE">💬</button>
      <div class="avatar"></div>
    </div>
  </div>
</nav>

<div class="container text-center mt-5">
  <h1 class="display-5">WELCOME</h1>
  <p class="text-muted">WEB MASIH TAHAP PENGEMBANGAN YEE</p>
</div>

<script>
  document.addEventListener('DOMContentLoaded', function () {
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    popoverTriggerList.map(function (popoverTriggerEl) {
      return new bootstrap.Popover(popoverTriggerEl);
    });
  });
</script>

</body>
</html>