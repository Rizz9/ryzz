<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = $_POST['text'] ?? '';
    $hashes = [
        'MD5' => md5($input),
        'SHA1' => sha1($input),
        'SHA256' => hash('sha256', $input),
        'SHA512' => hash('sha512', $input)
    ];
}
?><!DOCTYPE html><html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Hash Generator</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-dark text-light">
<div class="container py-5">
    <h1 class="text-center mb-4">🔐 Hash Generator</h1>
    <form method="post" class="card p-4 bg-secondary border-0 rounded-4 shadow">
        <div class="mb-3">
            <label for="text" class="form-label">Enter Text</label>
            <input type="text" class="form-control" id="text" name="text" required value="<?= htmlspecialchars($_POST['text'] ?? '') ?>">
        </div>
        <button type="submit" class="btn btn-warning">Generate Hash</button>
    </form><?php if (!empty($hashes)): ?>
    <div class="card mt-4 p-4 bg-secondary border-0 rounded-4 shadow">
        <h5 class="mb-3">🔎 Result:</h5>
        <ul class="list-group list-group-flush">
            <?php foreach ($hashes as $algo => $result): ?>
                <li class="list-group-item bg-dark text-light d-flex justify-content-between">
                    <strong><?= $algo ?>:</strong>
                    <span style="word-break: break-all;"> <?= $result ?> </span>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

</div>
</body>
</html>