<?php
function getInstagramVideo($url) {
    $api = "https://api.igdowload.net/api/instagram?url=" . urlencode($url); // contoh API pihak ketiga
    $json = file_get_contents($api);
    if (!$json) return false;
    $data = json_decode($json, true);
    if (isset($data['media'][0]['url'])) {
        return [
            'video_url' => $data['media'][0]['url'],
            'thumbnail' => $data['media'][0]['thumbnail']
        ];
    }
    return false;
}

$result = null;
if (isset($_POST['igurl'])) {
    $url = $_POST['igurl'];
    $result = getInstagramVideo($url);
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Instagram Downloader</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
  <div class="container py-5">
    <h2 class="text-center mb-4">📥 Instagram Downloader by R07</h2>
    <form method="post" class="card p-4 shadow-sm">
      <div class="mb-3">
        <label for="igurl" class="form-label">Instagram Post/Reels URL</label>
        <input type="url" class="form-control" name="igurl" id="igurl" required placeholder="https://www.instagram.com/reel/xxxx/">
      </div>
      <button type="submit" class="btn btn-primary w-100">Download</button>
    </form>

    <?php if ($result): ?>
    <div class="card mt-4 shadow-sm">
      <img src="<?= $result['thumbnail'] ?>" class="card-img-top">
      <div class="card-body text-center">
        <a href="<?= $result['video_url'] ?>" class="btn btn-success" download>Download Video</a>
      </div>
    </div>
    <?php elseif (isset($_POST['igurl'])): ?>
      <div class="alert alert-danger mt-4">❌ Failed to fetch video. Make sure the URL is public.</div>
    <?php endif; ?>
  </div>
</body>
</html>