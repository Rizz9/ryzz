<?php
$dir = __DIR__;
$allowed_ext = ['txt', 'html'];

// Hitung jumlah file upload yang valid
$fileCount = 0;
foreach (scandir($dir) as $f) {
  if ($f === basename(__FILE__) || is_dir($f) || pathinfo($f, PATHINFO_EXTENSION) === 'php') continue;
  $ext = strtolower(pathinfo($f, PATHINFO_EXTENSION));
  if (in_array($ext, $allowed_ext)) $fileCount++;
}

$ip = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
$ua = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';

$country = 'Unknown';
try {
  $info = @file_get_contents("https://ipinfo.io/{$ip}/json");
  if ($info) {
    $json = json_decode($info, true);
    $country = $json['country'] ?? 'Unknown';
  }
} catch (Exception $e) {
  $country = 'Unknown';
}

// Handle Upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
  $filename = basename($_FILES["file"]["name"]);
  $ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
  if (in_array($ext, $allowed_ext)) {
    $target = $dir . "/" . $filename;
    if (move_uploaded_file($_FILES["file"]["tmp_name"], $target)) {
      $msg = "<div class='alert alert-success'>✅ Uploaded: " . htmlspecialchars($filename) . "</div>";
    } else {
      $msg = "<div class='alert alert-danger'>❌ Upload failed.</div>";
    }
  } else {
    $msg = "<div class='alert alert-warning'>❌ Only .txt and .html files allowed.</div>";
  }
}

// Handle Download
if (isset($_GET['download'])) {
  $file = basename($_GET['download']);
  $path = $dir . '/' . $file;
  $ext = strtolower(pathinfo($path, PATHINFO_EXTENSION));
  if (is_file($path) && in_array($ext, $allowed_ext)) {
    header('Content-Description: File Transfer');
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . basename($file) . '"');
    header('Content-Length: ' . filesize($path));
    readfile($path);
    exit;
  } else {
    http_response_code(403);
    echo "❌ Download not allowed.";
    exit;
  }
}
?><!DOCTYPE html><html>
<head>
  <title>Uploader File by R07</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background-color: #f8f9fa; font-family: 'Segoe UI', sans-serif; }
    .info-box { position: fixed; top: 70px; right: 10px; z-index: 999; width: 280px; display: none; }
    .info-box p { margin-bottom: 5px; }
    .open-btn { position: fixed; top: 10px; right: 10px; z-index: 1000; }
    .table td, .table th { vertical-align: middle; }
  </style>
  <script>
    function toggleInfoBox() {
      const box = document.getElementById('infoBox');
      box.style.display = box.style.display === 'none' ? 'block' : 'none';
    }
  </script>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">Uploader R07</a>
    <button class="btn btn-light open-btn" onclick="toggleInfoBox()">☰ Info</button>
  </div>
</nav><div class="container mt-4">
  <h3 class="mb-3">Public File Uploader</h3>
  <p class="text-muted">Only <code>.txt</code> and <code>.html</code> files allowed</p>
  <?php if (isset($msg)) echo $msg; ?>
  <form method="post" enctype="multipart/form-data" class="mb-4">
    <div class="input-group">
      <input type="file" name="file" class="form-control" required>
      <button type="submit" class="btn btn-primary">Upload</button>
    </div>
  </form>  <h5>📁 File List</h5>
  <table class="table table-bordered table-hover">
    <thead class="table-secondary">
      <tr><th>Name</th><th>Size</th><th>Action</th></tr>
    </thead>
    <tbody>
<?php
foreach (scandir($dir) as $file) {
  if ($file === basename(__FILE__) || is_dir($file) || pathinfo($file, PATHINFO_EXTENSION) === 'php') continue;
  $size = filesize($file);
  $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
  echo "<tr><td>" . htmlspecialchars($file) . "</td><td>" . $size . " B</td><td>";
  if (in_array($ext, $allowed_ext)) {
    echo "<a href='?download=" . urlencode($file) . "' class='btn btn-sm btn-success'>📥 Download</a> ";
    echo "<a href='" . htmlspecialchars($file) . "' target='_blank' class='btn btn-sm btn-info'>🌐 Open</a>";
  } else {
    echo "<span class='text-muted'>No access</span>";
  }
  echo "</td></tr>";
}
?>
    </tbody>
  </table>
</div><div class="card shadow info-box bg-light border" id="infoBox">
  <div class="card-body">
    <h6 class="card-title">🔍 Info Pengguna</h6>
    <p>📝 <strong>User:</strong> Non-admin</p>
    <p>🌐 <strong>IP:</strong> <?= htmlspecialchars($ip) ?></p>
    <p>🗺️ <strong>Negara:</strong> <?= htmlspecialchars($country) ?></p>
    <p>📱 <strong>Perangkat:</strong> <?= htmlspecialchars($ua) ?></p>
    <p>📁 <strong>Jumlah Upload:</strong> <?= $fileCount ?></p>
    <p>🔐 <a href="../admin" class="btn btn-sm btn-outline-primary">Login Admin</a></p>
  </div>
</div></body>
</html>